# K8SInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**k8s_exit_code** | **int** |  | [optional] 
**k8s_signal** | **str** |  | [optional] 
**k8s_reason** | **str** |  | [optional] 
**k8s_message** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

