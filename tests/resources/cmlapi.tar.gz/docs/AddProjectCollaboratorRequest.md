# AddProjectCollaboratorRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** | The identifier of the project. | [optional] 
**username** | **str** | The username of the collaborator to add. | [optional] 
**permission** | **str** | The project permission of the collaborator to set. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

