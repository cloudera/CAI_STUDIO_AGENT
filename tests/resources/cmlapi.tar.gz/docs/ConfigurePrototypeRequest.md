# ConfigurePrototypeRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_huggingface_space** | **bool** |  | [optional] 
**is_community** | **bool** |  | [optional] 
**execute_amp_steps** | **bool** |  | [optional] 
**runtime_identifier** | **str** |  | [optional] 
**runtime_addon_identifiers** | **list[str]** | Optional runtime addons associated with this amp and used during amp configuration. | [optional] 
**run_import_tasks** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

