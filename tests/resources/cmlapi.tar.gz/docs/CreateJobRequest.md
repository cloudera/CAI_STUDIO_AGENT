# CreateJobRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** | ID of the project containing the job. | [optional] 
**name** | **str** | Name of the new job. | [optional] 
**script** | **str** | The script to run for the new job. | [optional] 
**cpu** | **float** | CPU cores to allocate to job runs for this job (default 1). | [optional] 
**memory** | **float** | Memory in GB to allocate to job runs for this job (default 1). | [optional] 
**nvidia_gpu** | **int** | Number of Nvidia GPUs to allocate to this job (default 0). | [optional] 
**parent_job_id** | **str** |  | [optional] 
**environment** | **dict(str, str)** | Default environment variables to include in job runs for this job. | [optional] 
**arguments** | **str** |  | [optional] 
**timeout** | **int** | Timeout in seconds of job runs for this job. | [optional] 
**schedule** | **str** | Schedule to run a job automatically. Cannot be used in a dependency job. Follows the cron format. For example, to execute the job every Monday at 1 PM UTC, the schedule would be \&quot;0 13 * * 1\&quot; without quotes. | [optional] 
**kernel** | **str** | Kernel to run the job runs on. Possible values are python3, python2, r, or scala. Should not be set if the project uses ML Runtimes. | [optional] 
**recipients** | [**list[JobRecipient]**](JobRecipient.md) | An optional list of recipients to receive notifications for job events such as successful runs, failures, and manual stops. | [optional] 
**attachments** | **list[str]** | Files to attach (with path relative to /home/cdsw/) in notification emails. For example, to attach a file located at /home/cdsw/report/result.csv, include \&quot;report/result.csv\&quot; in the array for this field. | [optional] 
**runtime_identifier** | **str** | The runtime image identifier to use if this job is part of a ML Runtime project. Must be set if using ML Runtimes. | [optional] 
**runtime_addon_identifiers** | **list[str]** | A list of runtime addon identifiers associated with this job. | [optional] 
**kill_on_timeout** | **bool** | Whether to kill the job on timeout. This field does nothing if the timeout is not set. | [optional] 
**timezone** | **str** | Timezone of the job. Relevant only when schedule (recurring jobs) is provided (default &#x27;America/Los_Angeles&#x27;). | [optional] 
**paused** | **bool** | Whether to create the job in paused state. Relevant only when schedule (recurring jobs) is provided. Recurring jobs are put in un-paused state by default. | [optional] 
**parent_id** | **str** | Optional dependent job if this new job is a dependency. Setting this to a parent job will make this job run when the parent job completes. Cannot be used alongside \&quot;schedule\&quot;. | [optional] 
**success_recipients** | **str** |  | [optional] 
**failure_recipients** | **str** |  | [optional] 
**timeout_recipients** | **str** |  | [optional] 
**stopped_recipients** | **str** |  | [optional] 
**run_as** | **int** |  | [optional] 
**accelerator_label_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

