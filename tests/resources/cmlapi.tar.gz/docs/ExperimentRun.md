# ExperimentRun

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the ExperimentRun. | [optional] 
**name** | **str** | Run Name. | [optional] 
**experiment_id** | **str** | The experiment ID. | [optional] 
**user** | [**ShortUser**](ShortUser.md) |  | [optional] 
**status** | [**ExperimentRunStatus**](ExperimentRunStatus.md) |  | [optional] 
**start_time** | **datetime** | Unix timestamp of when the ExperimentRun started in milliseconds. | [optional] 
**end_time** | **datetime** | Unix timestamp of when the ExperimentRun ended in milliseconds. | [optional] 
**artifact_uri** | **str** | Sub directory of actual experiment artifacts location. | [optional] 
**data** | [**ExperimentRunData**](ExperimentRunData.md) |  | [optional] 
**inputs** | [**ExperimentRunInputs**](ExperimentRunInputs.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

