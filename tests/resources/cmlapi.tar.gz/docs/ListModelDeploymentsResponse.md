# ListModelDeploymentsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_deployments** | [**list[ModelDeployment]**](ModelDeployment.md) | The page of model deployments. | [optional] 
**next_page_token** | **str** | The next page token. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

