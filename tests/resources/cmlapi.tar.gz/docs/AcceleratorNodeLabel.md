# AcceleratorNodeLabel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**label_key** | **str** |  | [optional] 
**label_value** | **str** |  | [optional] 
**availability** | **bool** |  | [optional] 
**max_gpu_count** | **str** |  | [optional] 
**current_gpu_count** | **str** |  | [optional] 
**max_gpu_per_workload** | **str** |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**updated_at** | **datetime** |  | [optional] 
**default_quota** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

