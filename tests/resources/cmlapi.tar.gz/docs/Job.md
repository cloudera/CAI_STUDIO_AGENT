# Job

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Public identifier of the job. Output only. | [optional] 
**cpu** | **float** | vCPU cores available for the job. | [optional] 
**created_at** | **datetime** | When the job was created. Output only. | [optional] 
**creator** | [**ShortUser**](ShortUser.md) |  | [optional] 
**engine_image_id** | **str** | ID of the engine image. Will be 0 if using runtimes. Output only. | [optional] 
**english_schedule** | **str** | English schedule. Output only. | [optional] 
**arguments** | **str** | Arguments to the job. | [optional] 
**type** | **str** | Type of job, whether it&#x27;s \&quot;manual\&quot;, \&quot;cron\&quot;, or \&quot;dependent\&quot; Output only. | [optional] 
**kernel** | **str** | Kernel the job uses. | [optional] 
**memory** | **float** | Job memory in GB. | [optional] 
**name** | **str** | Job name. | [optional] 
**parent_id** | **str** | ID of the parent job - if the job is \&quot;dependent\&quot;. | [optional] 
**paused** | **bool** | Whether the job is paused. Output only. | [optional] 
**schedule** | **str** | The job schedule. | [optional] 
**script** | **str** | The script to execute for the job. | [optional] 
**timeout** | **str** | Timeout of a job run for this job. | [optional] 
**timezone** | **str** | Timezone of the job if this is a scheduled job. Output only. | [optional] 
**updated_at** | **datetime** | When the job was last updated. Output only. | [optional] 
**environment** | **str** | The default environment variables for the job, as JSON. | [optional] 
**nvidia_gpu** | **int** | The number of nvidia GPUs allocated for this job. | [optional] 
**runtime_identifier** | **str** | The runtime image identifier if this is a runtime job. Will be blank if using engines. | [optional] 
**runtime_addon_identifiers** | **list[str]** | The runtime addons associated with this job. | [optional] 
**kill_on_timeout** | **bool** | Whether to kill this job when it times out. | [optional] 
**project** | [**ShortProject**](ShortProject.md) |  | [optional] 
**owner** | [**ShortUser**](ShortUser.md) |  | [optional] 
**run_as** | **int** |  | [optional] 
**accelerator_label_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

