# ExperimentRunData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metrics** | [**list[Metric]**](Metric.md) | ExperimentRun metrics. | [optional] 
**params** | [**list[Tag]**](Tag.md) | ExperimentRun parameters. | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Additional metadata key-value pairs. | [optional] 
**files** | [**list[FileInfo]**](FileInfo.md) | File location (relative to the experiment run&#x27;s root artifact directory) and metadata for artifacts. | [optional] 
**registered_model_metadata** | [**list[RegisteredModelMetadata]**](RegisteredModelMetadata.md) | RegisteredModelMetadata is used to show what model version is registered for this model. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

