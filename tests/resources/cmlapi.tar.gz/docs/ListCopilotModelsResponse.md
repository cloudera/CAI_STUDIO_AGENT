# ListCopilotModelsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**copilot_models** | [**list[CopilotModel]**](CopilotModel.md) | The copilot models in this page. | [optional] 
**next_page_token** | **str** | The page token for the next page. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

