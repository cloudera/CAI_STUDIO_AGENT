# AcceleratorBasedUserQuota

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **str** |  | [optional] 
**accelerator_id** | **str** |  | [optional] 
**gpu_quota** | **str** |  | [optional] 
**accelerator_key** | **str** |  | [optional] 
**accelerator_value** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

