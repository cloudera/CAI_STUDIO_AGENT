# CreateSyncedTeamRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **str** |  | [optional] 
**group_permissions** | [**list[GroupPermission]**](GroupPermission.md) |  | [optional] 
**bio** | **str** | Bio of the team. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

