# ListExperimentRunsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**experiment_runs** | [**list[ExperimentRun]**](ExperimentRun.md) | ExperimentRuns that match the search criteria. | [optional] 
**next_page_token** | **str** | Next page token is a value that can be added to a new ListJobs call to fetch the next page of jobs, if any remain. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

