# JobRecipient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** |  | [optional] 
**notify_on_success** | **bool** | Whether to notify on job success. | [optional] 
**notify_on_failure** | **bool** | Whether to notify on job failure. | [optional] 
**notify_on_timeout** | **bool** | Whether to notify on job timeout. | [optional] 
**notify_on_stop** | **bool** | Whether to notify when the job is stopped. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

