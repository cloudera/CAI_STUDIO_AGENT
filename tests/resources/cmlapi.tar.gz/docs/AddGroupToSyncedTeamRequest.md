# AddGroupToSyncedTeamRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**team_name** | **str** |  | [optional] 
**group_permission** | [**GroupPermission**](GroupPermission.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

