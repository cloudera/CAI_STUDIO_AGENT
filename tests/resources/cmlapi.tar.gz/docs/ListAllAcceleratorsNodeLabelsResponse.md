# ListAllAcceleratorsNodeLabelsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accelerator_node_label** | [**list[AcceleratorNodeLabel]**](AcceleratorNodeLabel.md) |  | [optional] 
**next_page_token** | **str** | A token to fetch the next page of accelerator node labels. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

