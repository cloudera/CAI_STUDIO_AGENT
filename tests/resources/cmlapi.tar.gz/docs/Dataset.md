# Dataset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**digest** | **str** | Dataset digest, e.g. an md5 hash of the dataset that uniquely identifies it within datasets of the same name. | [optional] 
**source_type** | **str** | Source information for the dataset. Note that the source may not exactly reproduce the dataset if it was transformed / modified before use with MLflow. | [optional] 
**source** | **str** | The type of the dataset source, e.g. ‘databricks-uc-table’, ‘DBFS’, ‘S3’, ... | [optional] 
**schema** | **str** | The schema of the dataset. E.g., MLflow ColSpec JSON for a dataframe, MLflow TensorSpec JSON for an ndarray, or another schema format. | [optional] 
**profile** | **str** | The profile of the dataset. Summary statistics for the dataset, such as the number of rows in a table, the mean / std / mode of each column in a table, or the number of elements in an array. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

