# Application

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | public identifier of the application. | [optional] 
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**creator** | [**ShortUser**](ShortUser.md) |  | [optional] 
**script** | **str** |  | [optional] 
**subdomain** | **str** |  | [optional] 
**status** | [**ApplicationStatus**](ApplicationStatus.md) |  | [optional] 
**created_at** | **datetime** | When the application was created. | [optional] 
**stopped_at** | **datetime** |  | [optional] 
**updated_at** | **datetime** |  | [optional] 
**starting_at** | **datetime** |  | [optional] 
**running_at** | **datetime** |  | [optional] 
**kernel** | **str** | The kernel of the application. | [optional] 
**cpu** | **float** | The number of vCPU allocated for the job run application. | [optional] 
**memory** | **float** | The amount of memory allocated for the application (in GB). | [optional] 
**nvidia_gpu** | **int** | The number of Nvidia GPUs allocated for the application. | [optional] 
**bypass_authentication** | **bool** |  | [optional] 
**environment** | **str** |  | [optional] 
**runtime_identifier** | **str** | Runtime image this application should run on. | [optional] 
**runtime_addon_identifiers** | **list[str]** | The list of runtime addons that this application uses. | [optional] 
**run_as** | **int** |  | [optional] 
**cdv_app** | **bool** |  | [optional] 
**accelerator_label_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

