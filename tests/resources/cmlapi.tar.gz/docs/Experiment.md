# Experiment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the experiment. | [optional] 
**project_id** | **str** |  | [optional] 
**name** | **str** | Human readable name that identifies the experiment. | [optional] 
**artifact_location** | **str** | Location where artifacts for the experiment are stored. | [optional] 
**created_at** | **datetime** | Birth date in YYYY-MM-DDThh:mm:ss.uuZ format (ISO 8601 format). Output only. | [optional] 
**updated_at** | **datetime** | Last update in YYYY-MM-DDThh:mm:ss.uuZ format (ISO 8601 format). Output only. | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Tags: Additional metadata key-value pairs. | [optional] 
**lifecycle_stage** | **str** | lifecycle_stage shows the status of experiment. | [optional] 
**user** | [**ShortUser**](ShortUser.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

