# LatestSyncStatusResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**sync_type** | **str** |  | [optional] 
**sync_model** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**logs** | **str** |  | [optional] 
**message** | **str** |  | [optional] 
**created_at** | **str** |  | [optional] 
**total_synced_users** | **int** |  | [optional] 
**total_active_users** | **int** |  | [optional] 
**total_deactivated_users** | **int** |  | [optional] 
**synced_by** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

