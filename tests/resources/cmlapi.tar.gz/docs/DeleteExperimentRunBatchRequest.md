# DeleteExperimentRunBatchRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** |  | [optional] 
**experiment_id** | **str** |  | [optional] 
**run_id** | **str** |  | [optional] 
**metrics** | **list[str]** | List of metric names to be deleted. | [optional] 
**params** | **list[str]** | List of param names to be deleted. | [optional] 
**tags** | **list[str]** | List of tags to be deleted. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

