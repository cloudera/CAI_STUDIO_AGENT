# CreateModelRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** | ID of the project containing the model. | [optional] 
**name** | **str** | Name of the model. | [optional] 
**description** | **str** | Description of the model. | [optional] 
**disable_authentication** | **bool** | Whether to disable authentication for requests to deployments of this model. | [optional] 
**registered_model_id** | **str** | Registered Model ID. | [optional] 
**run_as** | **int** |  | [optional] 
**visibility** | **str** | Visibility of the model. | [optional] 
**auto_build_config** | [**ShortCreateModelBuild**](ShortCreateModelBuild.md) |  | [optional] 
**auto_deployment_config** | [**ShortCreateModelDeployment**](ShortCreateModelDeployment.md) |  | [optional] 
**auto_build_model** | **bool** |  | [optional] 
**auto_deploy_model** | **bool** |  | [optional] 
**accelerator_label_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

