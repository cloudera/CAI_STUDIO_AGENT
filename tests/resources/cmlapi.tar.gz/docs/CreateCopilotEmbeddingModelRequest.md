# CreateCopilotEmbeddingModelRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | **str** |  | [optional] 
**name** | **str** | Name of the embedding model. E.g. &#x27;Llama2 70b&#x27;. | [optional] 
**endpoint** | **str** | For CMLServing models, the model endpoint. | [optional] 
**enabled** | **bool** | Whether or not to enable this embedding model for use in Copilot. | [optional] 
**default** | **bool** | Whether to make this the default Copilot embedding model. If set to true, the existing default Copilot model will no longer be default, and this one will become the default. | [optional] 
**provider_id** | **str** | The provider_id string for this model. AI Inference models should have \&quot;cloudera\&quot;. For Amazon Bedrock models, Anthropic/Claude models should have \&quot;bedrock-chat\&quot;, while others should have \&quot;bedrock\&quot;. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

