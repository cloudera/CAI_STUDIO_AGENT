# CopilotEmbeddingModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of the model. Must be unique. | [optional] 
**provider** | **str** | The Model Provider. E.g. &#x27;Amazon Bedrock&#x27; or &#x27;CML Serving&#x27;. | [optional] 
**name** | **str** | The name of the model. E.g. &#x27;Llama2 70b&#x27;. The combination of the provider and name fields must be unique. | [optional] 
**endpoint** | **str** | For CMLServing models, the model endpoint string to connect to. | [optional] 
**enabled** | **bool** | Whether a model is enabled for Copilot use. | [optional] 
**default** | **bool** | Whether this model is the default model for Copilot use. Only one model can be the default Copilot model. Only enabled models can be the default. | [optional] 
**provider_id** | **str** | The provider_id string for this model. AI Inference models should have \&quot;cloudera\&quot;. For Amazon Bedrock models, Anthropic/Claude models should have \&quot;bedrock-chat\&quot;, while others should have \&quot;bedrock\&quot;. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

