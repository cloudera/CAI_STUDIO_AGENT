# CreateModelBuildRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** | ID of the project containing the model build. | [optional] 
**model_id** | **str** | The ID of the model that will the build. | [optional] 
**comment** | **str** | A comment associated with the build. | [optional] 
**file_path** | **str** | The path to the file to build. | [optional] 
**function_name** | **str** | The function name to run when executing the build. | [optional] 
**kernel** | **str** | The kernel the model build should use. | [optional] 
**runtime_identifier** | **str** | The runtime ID the model build should use. | [optional] 
**runtime_addon_identifiers** | **list[str]** | The runtime addons the model build should use, if using runtimes. | [optional] 
**registered_model_version_id** | **str** | ID of the registered model version. | [optional] 
**auto_deployment_config** | [**ShortCreateModelDeployment**](ShortCreateModelDeployment.md) |  | [optional] 
**auto_deploy_model** | **bool** |  | [optional] 
**model_root_dir** | **str** |  | [optional] 
**build_script_path** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

