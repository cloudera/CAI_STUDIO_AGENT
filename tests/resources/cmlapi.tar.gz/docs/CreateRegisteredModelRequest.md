# CreateRegisteredModelRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** |  | [optional] 
**experiment_id** | **str** | Experiment ID the run belongs to. | [optional] 
**run_id** | **str** | ID of the ExperimentRun. | [optional] 
**model_path** | **str** | Model path of model that is getting registered to model registry. | [optional] 
**model_name** | **str** |  | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Tags for model. | [optional] 
**description** | **str** | Registered model description. | [optional] 
**notes** | **str** | Registered model version notes. | [optional] 
**visibility** | [**Visibility**](Visibility.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

