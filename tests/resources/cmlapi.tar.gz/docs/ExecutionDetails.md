# ExecutionDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**workload_crn** | **str** |  | [optional] 
**workload_execution_crn** | **str** |  | [optional] 
**parent_workload_execution_crn** | **str** |  | [optional] 
**pod_name** | **str** |  | [optional] 
**start_time** | **datetime** |  | [optional] 
**end_time** | **datetime** |  | [optional] 
**allocated_cpu_cores** | **float** |  | [optional] 
**allocated_memory_gb** | **float** |  | [optional] 
**allocated_gpu_cores** | **float** |  | [optional] 
**status** | **str** |  | [optional] 
**failure_reason** | **str** |  | [optional] 
**run_as_user_crn** | **str** |  | [optional] 
**run_as_user_name** | **str** |  | [optional] 
**runtime** | [**RuntimeDetails**](RuntimeDetails.md) |  | [optional] 
**spark_event_log_dir** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

