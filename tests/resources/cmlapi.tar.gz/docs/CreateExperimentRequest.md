# CreateExperimentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**tags** | [**list[Tag]**](Tag.md) |  | [optional] 
**artifact_location** | **str** | Location where all artifacts for the experiment are stored. URI of the directory where artifacts should be uploaded. This can be a local path (starting with \&quot;/\&quot;), or a distributed file system (DFS) path, like &#x60;&#x60;s3://bucket/directory&#x60;&#x60; or &#x60;&#x60;dbfs:/my/directory&#x60;&#x60;. If not set, the local &#x60;&#x60;./mlruns&#x60;&#x60; directory is  chosen. | [optional] 
**engine_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

