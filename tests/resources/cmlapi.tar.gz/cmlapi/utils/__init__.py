from cmlapi.utils.cursor import Cursor
from cmlapi.utils.default_client import default_client