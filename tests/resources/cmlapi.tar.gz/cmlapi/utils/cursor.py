class Cursor:
    """Pagination helper.

    A class that yields individual items from a callable until all pages are exhausted.
    The callable must return ListResponse objects.
    """

    def __init__(self, method, *args, **kwargs):
        """Initializes Curosr class.

        :param function method: Function that returns the list response eg: api.list_projects returns ListProjectsResponse.
        :param *args: Positional arguments to be passed to the method.
        :param **kwargs: keyword arguments to be passed to the method.
        """
        self.method = method
        self.args = args
        self.local_kwargs = kwargs.copy()
        if "page_size" not in kwargs:
            self.local_kwargs["page_size"] = 100

    def items(self):
        """Yields items returned by a callable that returns ListResponse.

        :return: yields items returned by method.
        """
        while True:
            page = self.method(*self.args, **self.local_kwargs)
            # There should be only two attributes in returned objects
            # jobs/projects/... and next_page_token
            attrs = [k for k in page.attribute_map.keys() if k != "next_page_token"]
            type_attr = attrs[0]
            items = getattr(page, type_attr)
            if len(items) == 0:
                return
            for item in items:
                yield item
            self.local_kwargs["page_token"] = page.next_page_token
            if not page.next_page_token or len(page.next_page_token) == 0:
                return
